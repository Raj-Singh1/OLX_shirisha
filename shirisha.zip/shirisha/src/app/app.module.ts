import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from "@angular/forms"
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import {Routes,RouterModule} from '@angular/router'
import { CommonService } from './common.service';
import {HttpModule} from "@angular/http";
import { LoginComponent } from './login/login.component'
const appRoutes:Routes=[
  {path:'app',component:AppComponent},
  {path:'add',component:HomeComponent},
  {path:'userlogin',component:LoginComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,RouterModule.forRoot(appRoutes),FormsModule,HttpModule,ReactiveFormsModule
  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
