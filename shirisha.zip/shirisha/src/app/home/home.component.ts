import { Component, OnInit } from '@angular/core';

import { CommonService } from "../common.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  Repdata;
  valbutton="Save"
  constructor(private newService:CommonService) { }

  ngOnInit() {
  }
  onSave=function(user,isValid:boolean){
    user.mode=this.valbutton;
    this.newService.saveUser(user).subscribe(data=>{alert(data.data);
    this.ngOnInit();
    },
    error=>this.errorMessage=error)
  }
}
