import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from "../common.service";
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  cDuration: any = null;
  temp: Number = 0;
  myForm: FormGroup;
  flag1: boolean = true;
  flag: boolean = true;
  constructor(private fb: FormBuilder,private newService:CommonService) {
    this.myForm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    })
  }

  ngOnInit() {
  }
  AddCourse(user) {
    this.flag1 = true;
    this.temp = 0;
    var usernameRegex = /^[a-zA-Z.]+[0-9]*@capgemini.com$/
    var passwordRegex = /^[a-zA-Z0-9.@$]{7,10}$/
    var password = this.myForm.get('password').value;
    var username = this.myForm.get('username').value.toLowerCase();
    if (this.myForm.valid) {
      if ((username.match(usernameRegex)) && (password.match(passwordRegex))) {
        alert("hahahahaha");
        this.newService.verify(user).subscribe(data=>{alert(data.data);
          this.ngOnInit();
          })
      }
      else {
        this.flag1 = false
      }

    }
    else {
      alert("not valid")
    }
  }
}
